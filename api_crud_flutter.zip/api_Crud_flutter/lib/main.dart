import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'Controller/UserProvider.dart';
import 'JsonApi/postApi.dart';
import 'JsonApi/post_provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<UserProvider>(
          create: (context) => UserProvider(),
        ),
        ChangeNotifierProvider<PostProvider>(
          create: (context) => PostProvider(),
        ),
      ],
      child: const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: JsonPostApis(),
      ),
    );
  }
}
