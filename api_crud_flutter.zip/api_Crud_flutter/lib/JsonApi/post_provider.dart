import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'datamodel.dart';

class PostProvider extends ChangeNotifier {
  List<Post> _posts = [];
  List<Post> get posts => _posts;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<void> fetchPosts() async {
    _isLoading = true;
    notifyListeners();

    try {
      var response = await http.get(
        Uri.parse("https://jsonplaceholder.typicode.com/posts"),
      );
      if (response.statusCode == 200) {
        List<dynamic> jsonData = jsonDecode(response.body);
        _posts = jsonData.map((json) => Post.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load posts');
      }
    } catch (e) {
      throw Exception("Failed to load data: $e");
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addPost(Post post) async {
    try {
      var response = await http.post(
        Uri.parse("https://jsonplaceholder.typicode.com/posts"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(post.toJson()),
      );
      if (response.statusCode == 201) {
        Post newPost = Post.fromJson(jsonDecode(response.body));
        _posts.add(newPost);
        print("Post Added Susscussfully");
        notifyListeners();
      } else {
        throw Exception('Failed to add post');
      }
    } catch (e) {
      throw Exception("Failed to add post: $e");
    }
  }

  Future<void> updatePost(Post post) async {
    try {
      var response = await http.put(
        Uri.parse("https://jsonplaceholder.typicode.com/posts/${post.id}"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(post.toJson()),
      );
      if (response.statusCode == 200) {
        int index = _posts.indexWhere((p) => p.id == post.id);
        if (index != -1) {
          _posts[index] = post;
          print("Post Updated Susscussfully");
          notifyListeners();
        }
      } else {
        throw Exception('Failed to update post');
      }
    } catch (e) {
      throw Exception("Failed to update post: $e");
    }
  }

  Future<void> deletePost(int id) async {
    try {
      var response = await http.delete(
        Uri.parse("https://jsonplaceholder.typicode.com/posts/$id"),
      );
      if (response.statusCode == 200) {
        _posts.removeWhere((post) => post.id == id);
        print("Post Delete Susscussfully");
        notifyListeners();
      } else {
        throw Exception('Failed to delete post');
      }
    } catch (e) {
      throw Exception("Failed to delete post: $e");
    }
  }
}
