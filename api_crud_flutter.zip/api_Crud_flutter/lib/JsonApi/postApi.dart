import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'post_provider.dart';
import 'datamodel.dart';

class JsonPostApis extends StatefulWidget {
  const JsonPostApis({super.key});

  @override
  _JsonPostApisState createState() => _JsonPostApisState();
}

class _JsonPostApisState extends State<JsonPostApis> {
  final _titleController = TextEditingController();
  final _bodyController = TextEditingController();
  Post? _selectedPost; // To keep track of the post being edited

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<PostProvider>(context, listen: false).fetchPosts();
    });
  }

  // void _addOrUpdatePost(BuildContext context) {
  //   final title = _titleController.text;
  //   final body = _bodyController.text;
  //
  //   if (title.isNotEmpty && body.isNotEmpty) {
  //     if (_selectedPost == null) {
  //       // Add post
  //       final post = Post(userId: 1, id: 0, title: title, body: body);
  //       Provider.of<PostProvider>(context, listen: false).addPost(post);
  //     } else {
  //       // Update post
  //       final updatedPost = Post(
  //         userId: _selectedPost!.userId,
  //         id: _selectedPost!.id,
  //         title: title,
  //         body: body,
  //       );
  //       Provider.of<PostProvider>(context, listen: false).updatePost(updatedPost).then((_) {
  //         setState(() {
  //           _selectedPost = null;
  //         });
  //       });
  //     }
  //     _titleController.clear();
  //     _bodyController.clear();
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyan,
        title: const Text(
          "JsonPlaceholder Apis",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: Consumer<PostProvider>(
        builder: (context, postProvider, _){
          postProvider.fetchPosts();
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Title',
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: _bodyController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Body',
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(onPressed: (){
                    final addnewpost = Post(userId: 1, id: 0, title: _titleController.text, body: _bodyController.text);
                    postProvider.addPost(addnewpost);
                  }, child: Text("Add Post"))
                ],
              ),
              Expanded(
                child: Consumer<PostProvider>(
                  builder: (context, postProvider, _) {
                    if (postProvider.isLoading) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    return ListView.builder(
                      itemCount: postProvider.posts.length,
                      itemBuilder: (context, index) {
                        final post = postProvider.posts[index];
                        return ListTile(
                          title: Text(post.title),
                          subtitle: Text(post.body),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () {
                                  _titleController.text = post.title;
                                  _bodyController.text = post.body;
                                  setState(() {
                                    _selectedPost = post;
                                  });
                                },
                              ),
                              IconButton(
                                  icon: const Icon(Icons.delete),
                                  onPressed: () => postProvider.deletePost(post.id)
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      )
    );
  }
}
